(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const cities = [
    {name:"Tunis", area:"Grand Tunis", x:167, y:71, code:"TN-01"},
    {name:"Bizerte", area:"Nord", x:145, y:43, code:"TN-02"},
    {name:"Nabeul", area:"Cap Bon", x:198, y:112, code:"TN-03"},
    {name:"Sousse", area:"Centre-Est", x:205, y:171, code:"TN-04"},
    {name:"Kairouan", area:"Centre", x:151, y:190, code:"TN-05"},
    {name:"Sfax", area:"Sud-Est", x:193, y:255, code:"TN-06"},
    {name:"Tozeur", area:"Sud-Ouest", x:99, y:294, code:"TN-07"}
  ];
  let eventCount = 1284;
  let audioPlaying = false;
  let toastTimer;
  const safeText = (s) => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  function toast(message) {
    const node = $("toast"); node.textContent = message; node.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => node.classList.remove("show"), 2600);
  }
  function updateClock() {
    $("clock").textContent = new Intl.DateTimeFormat("fr-FR", {hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false}).format(new Date());
  }
  updateClock(); setInterval(updateClock, 1000);

  function addEvent(title, detail, type="green", tag="INFO") {
    const list = $("eventList");
    const row = document.createElement("div"); row.className = "event-row";
    const dot = document.createElement("span"); dot.className = `event-dot ${type}`;
    const body = document.createElement("div");
    const strong = document.createElement("strong"); strong.textContent = title;
    const small = document.createElement("small"); small.textContent = detail;
    body.append(strong, small);
    const time = document.createElement("time"); time.textContent = tag;
    row.append(dot, body, time); list.prepend(row);
    while (list.children.length > 7) list.lastElementChild.remove();
    eventCount += 1; $("eventCount").textContent = eventCount.toLocaleString("fr-FR");
  }

  function renderCities() {
    const markers = $("mapMarkers"); const list = $("cityList");
    markers.replaceChildren(); list.replaceChildren();
    cities.forEach((city, i) => {
      const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
      g.setAttribute("class", "map-marker"); g.setAttribute("tabindex", "0"); g.setAttribute("role", "button");
      g.setAttribute("aria-label", `${city.name}, point de démonstration`);
      const pulse = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      pulse.setAttribute("class", "marker-pulse"); pulse.setAttribute("cx", city.x); pulse.setAttribute("cy", city.y); pulse.setAttribute("r", "4");
      const dot = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      dot.setAttribute("cx", city.x); dot.setAttribute("cy", city.y); dot.setAttribute("r", "3.5");
      const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
      label.setAttribute("x", city.x + 7); label.setAttribute("y", city.y - 6); label.textContent = city.name;
      g.append(pulse, dot, label);
      const selectCity = () => {
        document.querySelectorAll(".city-item").forEach(el => el.classList.toggle("selected", el.dataset.code === city.code));
        toast(`${city.name} sélectionnée · point fictif ${city.code}`);
        addEvent(`Nœud ${city.name} sélectionné`, `Coordonnées schématiques · ${city.code}`, "blue", "CARTE");
      };
      g.addEventListener("click", selectCity); g.addEventListener("keydown", e => {if(e.key === "Enter" || e.key === " "){e.preventDefault();selectCity();}});
      markers.append(g);
      const item = document.createElement("div"); item.className = "city-item"; item.dataset.code = city.code; item.tabIndex = 0; item.setAttribute("role","button");
      const info = document.createElement("div"); const name = document.createElement("strong"); name.textContent = city.name; const area = document.createElement("small"); area.textContent = `${city.area} · ${city.code}`; info.append(name, area);
      const status = document.createElement("span"); status.className = "city-status"; status.textContent = "SIMULÉ";
      item.append(info,status); item.addEventListener("click", selectCity); item.addEventListener("keydown", e => {if(e.key === "Enter")selectCity();}); list.append(item);
    });
  }
  renderCities();

  $("radarRefresh").addEventListener("click", () => {
    const count = 3 + Math.floor(Math.random() * 5);
    $("beaconCount").textContent = String(count).padStart(2,"0");
    document.querySelectorAll(".blip").forEach((b, i) => {b.style.left = `${18 + Math.random()*65}%`;b.style.top = `${18 + Math.random()*65}%`;b.style.animationDelay = `${i*.17}s`;});
    addEvent("Balises de démonstration actualisées", `${count} échos fictifs affichés sur le radar`, "green", "RADAR");
    toast("Radar de simulation actualisé");
  });
  $("clearEvents").addEventListener("click", () => {$("eventList").replaceChildren();toast("Journal local effacé");});

  const helpText = [
    ["help","Commandes disponibles : help, status, scan-demo, nodes, clear, whoami"],
    ["status","Système : OPÉRATIONNEL · Mode : simulation locale · Réseau externe : non connecté"],
    ["scan-demo","Analyse fictive terminée : 3 événements de démonstration, 0 action externe."],
    ["nodes","Nœuds régionaux : Tunis, Bizerte, Nabeul, Sousse, Kairouan, Sfax, Tozeur."],
    ["whoami","kgt@local — utilisateur de la console de démonstration."]
  ];
  function terminalLine(text, cls="") {const p=document.createElement("p");if(cls)p.className=cls;p.textContent=text;$("terminalOutput").append(p);$("terminalOutput").scrollTop=$("terminalOutput").scrollHeight;}
  $("terminalForm").addEventListener("submit", e => {
    e.preventDefault(); const input=$("terminalInput"); const cmd=input.value.trim().toLowerCase(); if(!cmd)return;
    terminalLine(`kgt@local:~$ ${cmd}`, "term-green"); input.value="";
    if(cmd==="clear"){$("terminalOutput").replaceChildren();return;}
    const found=helpText.find(([key])=>key===cmd);
    if(found){terminalLine(found[1]);if(cmd==="scan-demo")addEvent("Scan fictif exécuté","Résultats générés dans le navigateur","blue","CLI");}
    else terminalLine(`Commande inconnue : ${cmd}. Tapez help.`, "term-error");
  });

  function evaluatePassword(value) {
    const checks = [
      {ok:value.length>=12,text:"12 caractères ou plus"},
      {ok:/[a-z]/.test(value)&&/[A-Z]/.test(value),text:"Lettres minuscules et majuscules"},
      {ok:/\d/.test(value)&&/[^A-Za-z0-9]/.test(value),text:"Chiffres et symboles"}
    ];
    let score=0;
    if(value.length>=8)score+=20;if(value.length>=12)score+=20;if(value.length>=16)score+=10;
    if(/[a-z]/.test(value))score+=10;if(/[A-Z]/.test(value))score+=10;if(/\d/.test(value))score+=10;if(/[^A-Za-z0-9]/.test(value))score+=15;
    if(/(.)\1{2,}/.test(value))score-=15;
    if(/password|azerty|qwerty|123456|admin/i.test(value))score-=25;
    score=Math.max(0,Math.min(100,score));
    const label=!value?"EN ATTENTE":score<30?"FAIBLE":score<55?"MOYEN":score<80?"BON":"TRÈS BON";
    $("strengthBar").style.width=`${value?score:0}%`;
    $("strengthBar").style.background=score<30?"#ff6e7a":score<55?"#f5c36a":"#50f0b0";
    $("strengthLabel").textContent=label;$("strengthScore").textContent=`${value?score:0} / 100`;
    $("passwordChecks").replaceChildren();
    checks.forEach(c=>{const li=document.createElement("li");li.className=c.ok?"pass":"";li.textContent=`${c.ok?"✓":"○"} ${c.text}`;$("passwordChecks").append(li);});
  }
  $("passwordInput").addEventListener("input", e=>evaluatePassword(e.target.value));
  $("togglePassword").addEventListener("click",()=>{$("passwordInput").type=$("passwordInput").type==="password"?"text":"password";});

  $("satRefresh").addEventListener("click",()=>{
    const states=["STABLE","ACQUISITION","LIAISON OK","VEILLE"];
    $("satState").textContent=states[Math.floor(Math.random()*states.length)];
    addEvent("Simulation satellite relancée","Paramètres orbitaux fictifs recalculés","blue","SAT");
    toast("Simulation satellite relancée");
  });

  let generatedUrl = "";
  $("create404").addEventListener("click",()=>{
    let slug=$("siteLabel").value.trim().toLowerCase().replace(/[^a-z0-9-]/g,"-").replace(/-+/g,"-").replace(/^-|-$/g,"").slice(0,40);
    if(!slug)slug="page-demo";
    const url=new URL(window.location.href);url.searchParams.set("demo404",slug);
    generatedUrl=url.href; $("generatedUrl").textContent=generatedUrl;$("generatedLink").hidden=false;
    addEvent("Lien 404 de démonstration créé",`Page fictive : ${slug}`,"amber","WEB");
    toast("Lien de démonstration créé");
  });
  $("copyLink").addEventListener("click",async()=>{
    try {await navigator.clipboard.writeText(generatedUrl);toast("Lien copié");}
    catch {const area=document.createElement("textarea");area.value=generatedUrl;document.body.append(area);area.select();const ok=document.execCommand("copy");area.remove();toast(ok?"Lien copié":"Copie indisponible : sélectionnez le lien");}
  });
  function show404IfRequested(){const params=new URLSearchParams(window.location.search);if(params.has("demo404")){$("demo404Overlay").hidden=false;document.querySelector(".error-card p").textContent=`Page « ${params.get("demo404").slice(0,50)} » introuvable dans la simulation KGT. Aucun site externe n'a été modifié.`;}}
  $("close404").addEventListener("click",()=>{const url=new URL(window.location.href);url.searchParams.delete("demo404");history.replaceState({}, "", url);$("demo404Overlay").hidden=true;});
  show404IfRequested();

  const eq=$("equalizer");for(let i=0;i<36;i++){const bar=document.createElement("i");bar.style.height=`${5+Math.random()*19}px`;eq.append(bar);}
  $("audioToggle").addEventListener("click",()=>{
    audioPlaying=!audioPlaying;eq.classList.toggle("playing",audioPlaying);
    $("audioToggle").textContent=audioPlaying?"Arrêter l'animation":"Démarrer l'animation";
    $("audioToggle").setAttribute("aria-pressed",String(audioPlaying));
    addEvent(audioPlaying?"Visualiseur audio animé":"Visualiseur audio arrêté",audioPlaying?"Spectre visuel fictif actif — aucun microphone utilisé":"Animation locale en pause","blue","AUDIO");
  });

  $("menuToggle").addEventListener("click",()=>{$("sidebar").classList.toggle("open");});
  document.querySelectorAll(".nav-link").forEach(link=>link.addEventListener("click",()=>{
    document.querySelectorAll(".nav-link").forEach(a=>a.classList.remove("active"));link.classList.add("active");$("sidebar").classList.remove("open");
  }));
  const sections=[...document.querySelectorAll("main section[id]")];
  if("IntersectionObserver" in window){
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{
      if(entry.isIntersecting){document.querySelectorAll(".nav-link").forEach(a=>a.classList.toggle("active",a.getAttribute("href")==="#"+entry.target.id));}
    }),{rootMargin:"-25% 0px -65% 0px"});
    sections.forEach(s=>observer.observe(s));
  }
})();